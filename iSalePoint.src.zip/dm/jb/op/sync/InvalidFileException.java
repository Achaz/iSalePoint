package dm.jb.op.sync;

public class InvalidFileException
  extends Exception
{
  public InvalidFileException(String paramString)
  {
    new Exception(paramString);
  }
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.op.sync.InvalidFileException
 * JD-Core Version:    0.7.0.1
 */
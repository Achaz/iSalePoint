package dm.jb.op.payment;

public abstract interface TxnRow {}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.op.payment.TxnRow
 * JD-Core Version:    0.7.0.1
 */
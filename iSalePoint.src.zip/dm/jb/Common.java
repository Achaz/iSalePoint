package dm.jb;

public class Common
{
  public static final byte PRODUCT_LOAD_INIT = 1;
  public static final byte PRODUCT_LOAD_LAZY = 2;
  public static final byte PRODUCT_LOAD_LAZY_AND_KEEP = 3;
  public static int ProductLoadsMode = 3;
  public static final int PRINTER_TYPE_LASER = 1;
  public static final int PRINTER_TYPE_DOT_MATRIX = 2;
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.Common
 * JD-Core Version:    0.7.0.1
 */
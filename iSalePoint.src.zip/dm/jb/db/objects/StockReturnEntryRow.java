package dm.jb.db.objects;

import dm.jb.db.gen.StockReturnEntryBaseRow;

public class StockReturnEntryRow
  extends StockReturnEntryBaseRow
{
  public StockReturnEntryRow(int paramInt, StockReturnEntryTableDef paramStockReturnEntryTableDef)
  {
    super(paramInt, paramStockReturnEntryTableDef);
  }
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.db.objects.StockReturnEntryRow
 * JD-Core Version:    0.7.0.1
 */
package dm.jb.db.objects;

import dm.jb.db.gen.StockInfoBaseRow;

public class StockInfoRow
  extends StockInfoBaseRow
{
  StockInfoRow(int paramInt, StockInfoTableDef paramStockInfoTableDef)
  {
    super(paramInt, paramStockInfoTableDef);
  }
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.db.objects.StockInfoRow
 * JD-Core Version:    0.7.0.1
 */
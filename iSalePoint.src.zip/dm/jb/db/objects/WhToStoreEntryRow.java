package dm.jb.db.objects;

import dm.jb.db.gen.WhToStoreEntryBaseRow;

public class WhToStoreEntryRow
  extends WhToStoreEntryBaseRow
{
  WhToStoreEntryRow(int paramInt, WhToStoreEntryTableDef paramWhToStoreEntryTableDef)
  {
    super(paramInt, paramWhToStoreEntryTableDef);
  }
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.db.objects.WhToStoreEntryRow
 * JD-Core Version:    0.7.0.1
 */
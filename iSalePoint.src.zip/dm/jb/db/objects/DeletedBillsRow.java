package dm.jb.db.objects;

import dm.jb.db.gen.DeletedBillsBaseRow;

public class DeletedBillsRow
  extends DeletedBillsBaseRow
{
  DeletedBillsRow(int paramInt, DeletedBillsTableDef paramDeletedBillsTableDef)
  {
    super(paramInt, paramDeletedBillsTableDef);
  }
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.db.objects.DeletedBillsRow
 * JD-Core Version:    0.7.0.1
 */
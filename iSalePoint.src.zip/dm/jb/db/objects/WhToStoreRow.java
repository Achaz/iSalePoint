package dm.jb.db.objects;

import dm.jb.db.gen.WhToStoreBaseRow;

public class WhToStoreRow
  extends WhToStoreBaseRow
{
  WhToStoreRow(int paramInt, WhToStoreTableDef paramWhToStoreTableDef)
  {
    super(paramInt, paramWhToStoreTableDef);
  }
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.db.objects.WhToStoreRow
 * JD-Core Version:    0.7.0.1
 */
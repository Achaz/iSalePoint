package dm.jb.db.objects;

import dm.jb.db.gen.CcTxnBaseRow;

public class CcTxnRow
  extends CcTxnBaseRow
{
  CcTxnRow(int paramInt, CcTxnTableDef paramCcTxnTableDef)
  {
    super(paramInt, paramCcTxnTableDef);
  }
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.db.objects.CcTxnRow
 * JD-Core Version:    0.7.0.1
 */
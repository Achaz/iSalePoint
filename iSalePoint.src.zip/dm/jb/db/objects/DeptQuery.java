package dm.jb.db.objects;

public class DeptQuery {}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.db.objects.DeptQuery
 * JD-Core Version:    0.7.0.1
 */
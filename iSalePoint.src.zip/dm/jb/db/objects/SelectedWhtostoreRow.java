package dm.jb.db.objects;

import dm.jb.db.gen.SelectedWhtostoreBaseRow;

public class SelectedWhtostoreRow
  extends SelectedWhtostoreBaseRow
{
  public SelectedWhtostoreRow(int paramInt, SelectedWhtostoreTableDef paramSelectedWhtostoreTableDef)
  {
    super(paramInt, paramSelectedWhtostoreTableDef);
  }
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.db.objects.SelectedWhtostoreRow
 * JD-Core Version:    0.7.0.1
 */
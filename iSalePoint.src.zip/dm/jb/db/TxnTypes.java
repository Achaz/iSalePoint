package dm.jb.db;

public final class TxnTypes
{
  public static final String TXN_TYPE_BILL_PAY = "BP";
  public static final String TXN_TYPE_REFUND = "RF";
  public static final String TXN_TYPE_ADDL_PAY = "AP";
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.db.TxnTypes
 * JD-Core Version:    0.7.0.1
 */
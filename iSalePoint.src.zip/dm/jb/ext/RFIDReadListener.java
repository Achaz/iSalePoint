package dm.jb.ext;

public abstract interface RFIDReadListener
{
  public abstract void dataRead(String paramString);
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.ext.RFIDReadListener
 * JD-Core Version:    0.7.0.1
 */
package dm.jb.ui.report.table;

import dm.jb.ui.report.ReportTypeConfigPanel;

public class TableReportConfigPanel
  extends ReportTypeConfigPanel
{}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.ui.report.table.TableReportConfigPanel
 * JD-Core Version:    0.7.0.1
 */
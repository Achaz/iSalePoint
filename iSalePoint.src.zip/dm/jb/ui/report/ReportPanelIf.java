package dm.jb.ui.report;

public abstract interface ReportPanelIf {}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.ui.report.ReportPanelIf
 * JD-Core Version:    0.7.0.1
 */
package dm.jb.ui.report;

import java.util.HashMap;
import javax.swing.JPanel;

public class ReportTypeConfigPanel
{
  public void showReport(HashMap<Comparable, Double> paramHashMap, boolean paramBoolean, String paramString, ReportOutputPanel paramReportOutputPanel) {}
  
  public JPanel getConfigPanel()
  {
    return null;
  }
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.ui.report.ReportTypeConfigPanel
 * JD-Core Version:    0.7.0.1
 */
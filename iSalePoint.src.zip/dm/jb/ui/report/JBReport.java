package dm.jb.ui.report;

import dm.tools.ui.AbstractMainPanel;

public abstract interface JBReport
{
  public abstract String getName();
  
  public abstract AbstractMainPanel getUI();
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.ui.report.JBReport
 * JD-Core Version:    0.7.0.1
 */
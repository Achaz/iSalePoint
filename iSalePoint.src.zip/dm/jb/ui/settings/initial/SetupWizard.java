package dm.jb.ui.settings.initial;

public abstract interface SetupWizard {}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.ui.settings.initial.SetupWizard
 * JD-Core Version:    0.7.0.1
 */
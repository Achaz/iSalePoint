package dm.jb.ui.settings;

import java.util.Locale;

public class CountrySettings
{
  public static final CountryInfo[] CountryInfos = { new CountryInfo("America (United States of America)", "$", Locale.US), new CountryInfo("Singapore", "$", Locale.UK), new CountryInfo("United Kingdom", "£", Locale.UK), new CountryInfo("India", "INR", Locale.UK), new CountryInfo("Oman", "OMR", Locale.UK) };
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.ui.settings.CountrySettings
 * JD-Core Version:    0.7.0.1
 */
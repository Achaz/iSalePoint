package dm.jb.ui.common;

public class JBUICommon
{
  public static final int UIMODE_NORMAL = 0;
  public static final int UIMODE_VISTA = 1;
  public static int uiMode = 0;
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.ui.common.JBUICommon
 * JD-Core Version:    0.7.0.1
 */
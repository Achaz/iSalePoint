package dm.jb.ui.billing;

import dm.jb.db.objects.CustomerRow;

public abstract interface CustomerPanelInterface
{
  public abstract void customerPanelOKClicked(CustomerRow paramCustomerRow);
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.ui.billing.CustomerPanelInterface
 * JD-Core Version:    0.7.0.1
 */
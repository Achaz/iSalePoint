package dm.jb.messages;

public class GeneralUIMessages_kn
  extends GeneralUIMessages_base
{
  public void initMessages()
  {
    addMessage("ಸ್ವಾಗತ", 36865);
    addMessage("ವಿಳಾಸ", 36868);
    addMessage("No.", 36867);
    addMessage("ಹೆಸರು", 36869);
    addMessage("ಗ್ರಾಹಕ ಸಂ.", 36870);
    addMessage("ದೂ   ರವಾಣಿ", 36871);
  }
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.messages.GeneralUIMessages_kn
 * JD-Core Version:    0.7.0.1
 */
package dm.jb.messages;

public class ProductMessages_kn
  extends ProductMessages_base
{
  public void initMessages()
  {
    addMessage("ಉತ್ಪನ್ನ", 131073);
    addMessage("ಉತ್ಪನ್ನ ಸ೦", 131077);
    addMessage("ಉತ್ಪನ್ನ", 131074);
    addMessage("ದರ", 131084);
    addMessage("Vendor", 131075);
    addMessage("ಪ್ರಮಾಣ", 131076);
  }
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.messages.ProductMessages_kn
 * JD-Core Version:    0.7.0.1
 */
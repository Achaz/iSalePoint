package dm.jb.messages;

public class Customer_kn
  extends Customer_base
{
  public static final int ERROR_MESSAGE_CUSTOMER_ID_EMPTY = 139281;
  public static final int BUTTON_LABEL_PREVIOUS = 139282;
  
  public void initMessages()
  {
    addMessage("ಗ್ರಾಹಕ ಸಂ", 139281);
  }
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.messages.Customer_kn
 * JD-Core Version:    0.7.0.1
 */
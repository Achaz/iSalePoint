package dm.jb.messages;

public class MenuUILabels_kn
  extends MenuUILabels_base
{
  public void initMessages()
  {
    addMessage("ಕಡತ", 131073);
    addMessage("ನಿಗ೯ಮನ", 131074);
  }
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.jb.messages.MenuUILabels_kn
 * JD-Core Version:    0.7.0.1
 */
package dm.tools.utils;

public class CommonConstants {}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.tools.utils.CommonConstants
 * JD-Core Version:    0.7.0.1
 */
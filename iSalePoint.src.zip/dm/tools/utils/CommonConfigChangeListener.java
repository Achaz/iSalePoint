package dm.tools.utils;

public abstract interface CommonConfigChangeListener
{
  public abstract void setConfigValues();
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.tools.utils.CommonConfigChangeListener
 * JD-Core Version:    0.7.0.1
 */
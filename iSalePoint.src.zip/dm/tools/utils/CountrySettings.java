package dm.tools.utils;

import dm.jb.ui.settings.CountryInfo;
import java.util.Locale;

public class CountrySettings
{
  public static final CountryInfo[] CountryInfos = { new CountryInfo("India", "Rs", Locale.UK), new CountryInfo("United States of America", "$", Locale.US), new CountryInfo("Oman", "OMR", Locale.UK) };
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.tools.utils.CountrySettings
 * JD-Core Version:    0.7.0.1
 */
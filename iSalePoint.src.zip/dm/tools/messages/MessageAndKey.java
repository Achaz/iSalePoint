package dm.tools.messages;

public class MessageAndKey
{
  public String message = null;
  public int key = -1;
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.tools.messages.MessageAndKey
 * JD-Core Version:    0.7.0.1
 */
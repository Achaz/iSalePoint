package dm.tools.messages;

public class ButtonLabels_kn
  extends ButtonLabels_base
{
  public void initMessages()
  {
    addMessage("ಮುಂದೆ", 135169);
    addMessage("ಹಿಂದೆ", 135170);
    addMessage("ಸಹಾಯ", 135171);
    addMessage("ನಿಗ೯ಮಿಸು", 135172);
    addMessage("ಕೊನೆಗೊಳಿಸು", 135173);
    addMessage("ಸರಿ", 135175);
  }
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.tools.messages.ButtonLabels_kn
 * JD-Core Version:    0.7.0.1
 */
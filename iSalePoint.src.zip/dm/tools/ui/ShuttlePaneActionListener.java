package dm.tools.ui;

public abstract interface ShuttlePaneActionListener
{
  public abstract void objectSelected(Object[] paramArrayOfObject);
  
  public abstract boolean addToFromList(Object paramObject);
  
  public abstract boolean addToToList(Object paramObject);
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.tools.ui.ShuttlePaneActionListener
 * JD-Core Version:    0.7.0.1
 */
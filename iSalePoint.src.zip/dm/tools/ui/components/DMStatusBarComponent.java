package dm.tools.ui.components;

import javax.swing.BorderFactory;
import javax.swing.JLabel;

public class DMStatusBarComponent
  extends JLabel
{
  public DMStatusBarComponent()
  {
    setBorder(BorderFactory.createBevelBorder(1));
  }
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.tools.ui.components.DMStatusBarComponent
 * JD-Core Version:    0.7.0.1
 */
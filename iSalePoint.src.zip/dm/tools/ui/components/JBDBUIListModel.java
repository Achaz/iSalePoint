package dm.tools.ui.components;

import javax.swing.DefaultListModel;

public class JBDBUIListModel
  extends DefaultListModel
{}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.tools.ui.components.JBDBUIListModel
 * JD-Core Version:    0.7.0.1
 */
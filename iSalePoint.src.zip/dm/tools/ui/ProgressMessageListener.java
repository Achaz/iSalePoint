package dm.tools.ui;

public abstract interface ProgressMessageListener
{
  public abstract void setValue(int paramInt);
  
  public abstract void setMessage(String paramString);
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.tools.ui.ProgressMessageListener
 * JD-Core Version:    0.7.0.1
 */
package dm.tools.ui;

public abstract interface ProgressWindowAction
{
  public abstract void startAction();
  
  public abstract String getActionName();
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.tools.ui.ProgressWindowAction
 * JD-Core Version:    0.7.0.1
 */
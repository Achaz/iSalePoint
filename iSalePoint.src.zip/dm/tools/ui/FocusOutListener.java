package dm.tools.ui;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

public abstract class FocusOutListener
  implements FocusListener
{
  public void focusGained(FocusEvent paramFocusEvent) {}
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.tools.ui.FocusOutListener
 * JD-Core Version:    0.7.0.1
 */
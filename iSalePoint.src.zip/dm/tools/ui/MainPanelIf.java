package dm.tools.ui;

import javax.swing.JPanel;

public abstract interface MainPanelIf
{
  public abstract void setDefaultFocus();
  
  public abstract JPanel getPanel();
  
  public abstract void windowDisplayed();
}


/* Location:           D:\pos\iSalePoint\iSalePoint.jar
 * Qualified Name:     dm.tools.ui.MainPanelIf
 * JD-Core Version:    0.7.0.1
 */